NetGrok Dependencies for Windows 98/NT/2000/XP/Vista
=====================================================

NetGrok depends on WinPCAP and jPCAP. To install both, do the following:

 - Run WinPcap_4_0_2.exe and follow the instructions it provides. 
 - Run JpcapSetup-0.7.exe and follow the instructions it provides.
